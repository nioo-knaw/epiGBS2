BiocGenerics:::testPackage("RnBeads")
